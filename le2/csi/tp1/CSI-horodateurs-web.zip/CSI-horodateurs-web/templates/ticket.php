<?php

// Si la page est appelée directement par son adresse, on redirige en passant pas la page index
// Pas de soucis de bufferisation, puisque c'est dans le cas où on appelle directement la page sans son contexte
if (basename($_SERVER["PHP_SELF"]) != "index.php")
{
  header("Location:../index.php?view=accueil");
  die("");
}

?>

<h1>Consulter un ticket</h1>

<?php

$plaque = valider('plaque', 'GET');
$ticketsEnCours = ticketsEnCours($plaque);

if (count($ticketsEnCours) === 0) {
  echo "<p>Vous n'avez aucun ticket de stationnement en cours.</p>";
} elseif (count($ticketsEnCours) === 1) {
  echo "<p>Votre ticket de stationnement en cours :</p>";
} else {
  echo "<p>Vous avez plusieurs ticket de stationnement en cours :</p>";
}

foreach ($ticketsEnCours as $ticket) {
//  print_r($ticket);
  $heuresDuree = floor($ticket['duree'] / 60);
  $minutesDuree = $ticket['duree'] - $heuresDuree*60;
  echo "<div class=\"divTicket\">\n";
    // Le bouton pour prolonger un ticket est désactivé, en attente d'implémentation
    echo "<input class=\"inputProlonger\" type=\"button\" value=\"Prolonger\" disabled=\"disabled\">\n";
    printf("<p>Date : %s</p>\n", date("d/m/Y", strtotime($ticket['date_debut'])));
    printf("<p>Heure de début : %s</p>\n",
      date("H:i", strtotime($ticket['heure_debut'])));
    printf("<p>Heure de fin : %s</p>\n",
      date("H:i", strtotime($ticket['heure_fin'])));
    echo "<p>Durée :";
    if ($heuresDuree > 0) {
      echo " $heuresDuree h";
    }
    if ($minutesDuree > 0) {
      echo " $minutesDuree min";
    }
    echo "<p>Horodateur utilisé : $ticket[adresse_horodateur]</p>\n";
    echo "<p>Zone tarifaire : $ticket[zone] (";
    printf("%.2f", $ticket['cout_horaire'] / 100);
    echo " €/h)</p>\n";
    printf("<p>Coût du ticket : %.2f €</p>\n", round($ticket['cout_ticket'], 2));
  echo "</div>\n";
}

if (count($ticketsEnCours) > 0) {
  echo "<p>Cliquez sur « Prolonger » pour ajouter du temps de stationnement sur un ticket.</p>";
}

echo "<p><a href=\"index.php?view=usager\">Retour</a></p>";

?>
