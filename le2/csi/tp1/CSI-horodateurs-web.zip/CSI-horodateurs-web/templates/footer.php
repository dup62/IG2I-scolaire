<?php

// Si la page est appelée directement par son adresse, on redirige en passant pas la page index
if (basename($_SERVER["PHP_SELF"]) != "index.php")
{
  header("Location:../index.php");
  die("");
}

?>

<!-- Fin du corps de page -->
</div>

<div id="pied">

</div>

</body>
</html>
