<?php

// Si la page est appelée directement par son adresse, on redirige en passant pas la page index
// Pas de soucis de bufferisation, puisque c'est dans le cas où on appelle directement la page sans son contexte
if (basename($_SERVER["PHP_SELF"]) != "index.php")
{
  header("Location:../index.php?view=accueil");
  die("");
}

?>

<h1>Page d'administration</h1>

<p>Pour tester le service, merci de consulter la <a href="index.php?view=usager">page des usagers du service</a>.</p>

<h2>Statistiques générales</h2>

<p>Horodateurs en fonctionnement :</p>
<?php
mkTable(listeHorodateurs());
?>

<p>Zones tarifaires :</p>
<?php
mkTable(listeZonesTarifaires());
?>

<p>Tickets du jour :</p>
<?php
mkTable(listeTicketsDuJour());
?>

