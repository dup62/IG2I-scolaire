<?php

// Si la page est appelée directement par son adresse, on redirige en passant pas la page index
// Pas de soucis de bufferisation, puisque c'est dans le cas où on appelle directement la page sans son contexte
if (basename($_SERVER["PHP_SELF"]) != "index.php")
{
  header("Location:../index.php?view=accueil");
  die("");
}

?>

<h1>Consulter un ticket</h1>

<div id="divPlaque">
  <form action="index.php">
    <input type="hidden" name="view" value="ticket" />
    <label for="inputTextPlaque">Entrez votre plaque d'immatriculation :</label>
    <br />
    <input id="inputTextPlaque" type="text" name="plaque" placeholder="AA-000-AA" />
  </form>
</div>

