<?php

// Si la page est appelée directement par son adresse, on redirige en passant pas la page index
// Pas de soucis de bufferisation, puisque c'est dans le cas où on appelle directement la page sans son contexte
if (basename($_SERVER["PHP_SELF"]) != "index.php")
{
  header("Location:../index.php?view=accueil");
  die("");
}

?>

<h1>Choisissez votre vue</h1>

<ul>
  <li><a href="index.php?view=admin">Vue administrateur</a></li>
  <li><a href="index.php?view=usager">Vue usager</a></li>
</ul>

<h2>Test de la base de données</h2>

<?php
$resTestBdd = testbdd();
echo "<p>La connexion à la base de données a réussi.</p>";
echo "<p>Liste des tables dans la base de données :</p>";
mkTable($resTestBdd);
?>

