<?php

/*
Partie modèle : on effectue ici tous les traimtements sur la base de données (lecture, insertion, suppression, mise à jour)
*/

include_once("maLibSQL.pdo.php");

/// Test de connexion ////////////////////////

// Liste les tables de la base : permet de tester la connexion à la base
function testBdd() {
  return parcoursRs(SQLSelect("SHOW TABLES"));
}

/// Statistiques admin ///////////////////////

// Liste des horodateurs (a)
function listeHorodateurs() {
  // TODO: Requête SQL à compléter
  return parcoursRs(SQLSelect("
    # Écrire la requête SQL ici
  "));
}

// Liste des zones tarifaires (b)
function listeZonesTarifaires() {
  // TODO: Requête SQL à compléter
  return parcoursRs(SQLSelect("
    # Écrire la requête SQL ici
  "));
}

// Liste des tickets du jour (e)
function listeTicketsDuJour() {
  // TODO: Requête SQL à compléter
  return parcoursRs(SQLSelect("
    # Écrire la requête SQL ici
  "));
}

/// Données usager ///////////////////////////

// Tickets en cours pour une plaque donnée
/*
Entrée : 1 argument
  - $plaque (chaîne de caractères contenant la plaque d'immatriculation)
Sortie : tableau de tableaux associatifs contenant chacun les entrées suivantes :
  - plaque : la plaque d'immatriculation
  - date_debut : la date de début de stationnement
  - heure_debut : l'heure de début de stationnement
  - duree : la duree de stationnement
  - heure_fin : l'heure de fin de stationnement
  - adresse_horodateur : l'adresse (numéro et rue) de l'horodateur utilisé
  - zone : le nom de la zone tarifaire
  - cout_horaire : le coût horaire de la zone tarifaire
  - cout_ticket : le coût total du ticket
  Ces noms peuvent être définis comme alias des colonnes dans la clause SELECT
*/
function ticketsEnCours($plaque) {
  // TODO: Requête SQL à compléter
  return parcoursRs(SQLSelect("
    # Écrire la requête SQL ici
  "));
}

?>
