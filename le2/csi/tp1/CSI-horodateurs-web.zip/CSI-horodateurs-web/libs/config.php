<?php

$BDD_host="localhost";
$BDD_user="root";
$BDD_password="root"; 
$BDD_base="csi_horodateur";

?>
